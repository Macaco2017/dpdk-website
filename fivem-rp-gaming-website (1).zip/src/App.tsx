import { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutPolice } from './components/AboutPolice';
import { FleetArsenal } from './components/FleetArsenal';
import { InterventionsFeed } from './components/InterventionsFeed';
import { TacticalCAD } from './components/TacticalCAD';
import { RecruitmentForm } from './components/RecruitmentForm';
import { Footer } from './components/Footer';
import { DiscordConnect } from './components/DiscordConnect';
import { BackgroundMusic } from './components/BackgroundMusic';
import { GamingBackground } from './components/GamingBackground';
import { WelcomeGate } from './components/WelcomeGate';

export default function App() {
  const [activeTab, setActiveTab] = useState('inicio');
  const [hasEntered, setHasEntered] = useState(false);

  const goToRecruitment = () => {
    setActiveTab('recrutamento');
    const el = document.getElementById('recrutamento');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const goToInterventions = () => {
    setActiveTab('intervencoes');
    const el = document.getElementById('intervencoes');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-transparent text-gray-100 flex flex-col font-inter selection:bg-fuchsia-600 selection:text-white relative">
      <GamingBackground />
      {!hasEntered && <WelcomeGate onContinue={() => setHasEntered(true)} />}
      
      {/* Primary Law Enforcement Navigation */}
      <Navbar 
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />
      <BackgroundMusic />

      {/* Main Tactical Workspace */}
      <main className="flex-1 relative z-10 max-w-[1180px] w-full mx-auto bg-[#080716]/92 shadow-[0_0_80px_rgba(0,0,0,0.55)] backdrop-blur-sm">
        
        {/* Cinematic Tactical Command Center Header & Radio Player */}
        <Hero 
          onGoToRecruitment={goToRecruitment}
          onGoToInterventions={goToInterventions}
        />

        {/* Discord connection panel */}
        <DiscordConnect />

        {/* DPDK Division Presentation with Action Multimedia */}
        <AboutPolice />

        {/* DPDK rank pyramid and progression rules */}
        <FleetArsenal />

        {/* Public Operations Feed & Creation Portal */}
        <InterventionsFeed />

        {/* Portuguese GTA RP radio code manual */}
        <TacticalCAD />

        {/* Secure Application Terminal mirroring Discord Delivery */}
        <RecruitmentForm />

      </main>

      {/* Corporate Hierarchy, Guidelines & Direct Server Integration */}
      <Footer 
        setActiveTab={setActiveTab}
      />

    </div>
  );
}
