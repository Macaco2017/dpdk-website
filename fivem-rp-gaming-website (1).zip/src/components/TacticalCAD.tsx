import React, { useState } from 'react';
import { Radio, Siren, ShieldAlert, Search, HeartPulse, CarFront, Gavel, UserCheck } from 'lucide-react';

interface RadioCode {
  code: string;
  meaning: string;
  usage: string;
  category: 'rotina' | 'emergencia' | 'transito' | 'investigacao';
}

const RADIO_CODES: RadioCode[] = [
  { code: 'QAP', meaning: 'Na escuta', usage: 'Usado para confirmar que a unidade está disponível na frequência.', category: 'rotina' },
  { code: 'QSL', meaning: 'Entendido / confirmado', usage: 'Confirma recepção clara de uma ordem ou informação.', category: 'rotina' },
  { code: 'QTH', meaning: 'Localização', usage: 'Pedido ou envio de localização exacta no mapa.', category: 'rotina' },
  { code: 'QRX', meaning: 'Aguarde', usage: 'Usado quando a unidade precisa de tempo antes de responder.', category: 'rotina' },
  { code: 'QRR', meaning: 'Apoio urgente', usage: 'Pedido de reforço prioritário para ocorrência em evolução.', category: 'emergencia' },
  { code: 'QRT', meaning: 'Fora de serviço', usage: 'Unidade termina patrulha, pausa operação ou abandona frequência.', category: 'rotina' },
  { code: '10-04', meaning: 'Afirmativo', usage: 'Resposta curta para confirmação operacional.', category: 'rotina' },
  { code: '10-08', meaning: 'Em serviço', usage: 'Unidade inicia patrulha activa.', category: 'rotina' },
  { code: '10-10', meaning: 'Negativo', usage: 'Resposta curta para negar uma ordem, descrição ou informação.', category: 'rotina' },
  { code: '10-20', meaning: 'Localização actual', usage: 'Pedido directo de posição da unidade.', category: 'rotina' },
  { code: '10-23', meaning: 'Cheguei ao local', usage: 'Confirma chegada ao ponto da ocorrência.', category: 'rotina' },
  { code: '10-31', meaning: 'Disparos / tiros', usage: 'Comunicação de disparos activos ou recentes.', category: 'emergencia' },
  { code: '10-32', meaning: 'Indivíduo armado', usage: 'Suspeito visivelmente armado ou ameaça com arma.', category: 'emergencia' },
  { code: '10-37', meaning: 'Veículo suspeito', usage: 'Viatura sob análise, com matrícula, comportamento ou ocupantes suspeitos.', category: 'transito' },
  { code: '10-38', meaning: 'Abordagem de trânsito', usage: 'Início de abordagem a veículo. Deve indicar QTH, modelo, cor e ocupantes.', category: 'transito' },
  { code: '10-50', meaning: 'Acidente de viação', usage: 'Colisão, despiste ou atropelamento. Pode exigir INEM/EMS.', category: 'transito' },
  { code: '10-52', meaning: 'Solicitar INEM/EMS', usage: 'Pedido de assistência médica para civil ou agente ferido.', category: 'emergencia' },
  { code: '10-70', meaning: 'Fuga a pé', usage: 'Suspeito abandonou veículo ou zona e iniciou fuga apeada.', category: 'emergencia' },
  { code: '10-76', meaning: 'A caminho', usage: 'Unidade desloca-se para a ocorrência indicada.', category: 'rotina' },
  { code: '10-80', meaning: 'Perseguição em curso', usage: 'Perseguição activa. Deve ser acompanhado de QTH, sentido e descrição do veículo.', category: 'transito' },
  { code: '10-90', meaning: 'Assalto / roubo em curso', usage: 'Ocorrência de roubo activo, normalmente com reféns ou ameaça armada.', category: 'emergencia' },
  { code: '10-99', meaning: 'Situação controlada', usage: 'Ocorrência terminada, sem necessidade de mais unidades.', category: 'rotina' },
  { code: 'Código 0', meaning: 'Silêncio total na frequência', usage: 'Apenas comando e unidades directamente envolvidas podem falar.', category: 'emergencia' },
  { code: 'Código 3', meaning: 'Prioridade máxima', usage: 'Deslocação com luzes e sirenes, apenas quando justificado pelo RP.', category: 'emergencia' },
  { code: 'Código 4', meaning: 'Sem perigo / resolvido', usage: 'Local seguro ou ocorrência terminada.', category: 'rotina' }
];

const CATEGORY_META = {
  rotina: { label: 'Rotina', icon: UserCheck, color: 'text-blue-400 border-blue-800 bg-blue-950/30' },
  emergencia: { label: 'Emergência', icon: Siren, color: 'text-red-400 border-red-800 bg-red-950/30' },
  transito: { label: 'Trânsito', icon: CarFront, color: 'text-amber-400 border-amber-800 bg-amber-950/30' },
  investigacao: { label: 'Investigação', icon: Search, color: 'text-cyan-400 border-cyan-800 bg-cyan-950/30' }
};

export const TacticalCAD: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<'todos' | RadioCode['category']>('todos');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCode, setSelectedCode] = useState<RadioCode>(RADIO_CODES[0]);

  const filteredCodes = RADIO_CODES.filter((item) => {
    const matchesCategory = activeCategory === 'todos' || item.category === activeCategory;
    const matchesSearch = `${item.code} ${item.meaning} ${item.usage}`.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <section id="cad" className="py-20 bg-[#050508] relative border-t border-blue-900/20 overflow-hidden">
      <div className="absolute top-0 right-0 w-full h-full radar-grid opacity-30 pointer-events-none" />
      <div className="absolute top-20 right-10 w-96 h-96 bg-blue-600/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-12 motion-reveal">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-blue-950/60 border border-blue-800/60 mb-3">
            <Radio className="w-3.5 h-3.5 text-blue-400" />
            <span className="text-[10px] font-orbitron font-bold text-blue-400 uppercase tracking-widest">
              Comunicação Operacional
            </span>
          </div>
          <h2 className="font-orbitron font-black text-3xl sm:text-4xl text-white tracking-tight motion-text">
            CÓDIGOS RÁDIO <span className="text-blue-500 text-glow-blue">GTA RP PORTUGUÊS</span>
          </h2>
          <p className="font-inter text-gray-400 mt-2 text-sm sm:text-base kinetic-panel rounded-xl p-3 border border-white/5 bg-black/20">
            Manual rápido para comunicações limpas, curtas e realistas. Usa estes códigos para manter a frequência organizada durante patrulhas, abordagens e intervenções.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-8 bg-[#09090f] border border-white/10 rounded-2xl p-5 sm:p-6 relative sweep-line overflow-hidden holo-card">
            <div className="relative z-10">
              <div className="flex flex-col md:flex-row gap-3 md:items-center md:justify-between mb-5">
                <div className="flex flex-wrap gap-2">
                  <button onClick={() => setActiveCategory('todos')} className={`px-3 py-1.5 rounded-lg border text-xs font-orbitron font-bold transition-all cursor-pointer ${activeCategory === 'todos' ? 'bg-white text-black border-white' : 'bg-white/5 text-gray-300 border-white/10 hover:bg-white/10'}`}>
                    Todos
                  </button>
                  {Object.entries(CATEGORY_META).map(([key, meta]) => {
                    const Icon = meta.icon;
                    return (
                      <button
                        key={key}
                        onClick={() => setActiveCategory(key as RadioCode['category'])}
                        className={`px-3 py-1.5 rounded-lg border text-xs font-orbitron font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                          activeCategory === key ? meta.color : 'bg-white/5 text-gray-300 border-white/10 hover:bg-white/10'
                        }`}
                      >
                        <Icon className="w-3.5 h-3.5" />
                        {meta.label}
                      </button>
                    );
                  })}
                </div>

                <div className="relative">
                  <Search className="w-4 h-4 text-gray-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Pesquisar código..."
                    className="w-full md:w-60 bg-black/50 border border-white/10 rounded-lg pl-9 pr-3 py-2 text-xs text-white focus:border-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
                {filteredCodes.map((item, index) => {
                  const meta = CATEGORY_META[item.category];
                  const isSelected = selectedCode.code === item.code;
                  return (
                    <button
                      key={`${item.code}-${index}`}
                      onClick={() => setSelectedCode(item)}
                      className={`text-left rounded-xl border p-4 transition-all cursor-pointer motion-reveal holo-card overflow-hidden ${
                        isSelected ? 'border-blue-400 bg-blue-950/35 glow-blue' : 'border-white/5 bg-black/25 hover:border-white/15 hover:bg-white/[0.04]'
                      }`}
                      style={{ animationDelay: `${Math.min(index, 9) * 45}ms` }}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-orbitron font-black text-lg text-white">{item.code}</span>
                        <span className={`text-[9px] font-rajdhani font-bold px-2 py-0.5 rounded border ${meta.color}`}>{meta.label}</span>
                      </div>
                      <h3 className="font-rajdhani font-bold text-blue-300 text-sm mt-2">{item.meaning}</h3>
                      <p className="text-[11px] text-gray-400 leading-relaxed mt-1 line-clamp-2">{item.usage}</p>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="lg:col-span-4 bg-[#09090f] border border-white/10 rounded-2xl p-6 sticky top-28 holo-card overflow-hidden">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-lg bg-blue-950/50 border border-blue-700 flex items-center justify-center">
                <ShieldAlert className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <span className="text-[10px] font-orbitron text-gray-500 uppercase">Código seleccionado</span>
                <h3 className="font-orbitron font-black text-2xl text-white motion-text">{selectedCode.code}</h3>
              </div>
            </div>

            <h4 className="font-orbitron font-bold text-blue-300 text-sm mb-2">{selectedCode.meaning}</h4>
            <p className="text-sm text-gray-300 leading-relaxed mb-5">{selectedCode.usage}</p>

            <div className="bg-black/35 border border-white/5 rounded-xl p-4 space-y-3">
              <div className="flex items-start gap-2 text-xs text-gray-300">
                <Gavel className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
                <span>Não uses códigos para fugir ao RP. O código deve clarificar a comunicação, não substituir a interpretação da ocorrência.</span>
              </div>
              <div className="flex items-start gap-2 text-xs text-gray-300">
                <HeartPulse className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <span>Em feridos, reféns ou disparos, prioriza segurança, pedido de apoio e comunicação curta.</span>
              </div>
            </div>

            <a
              href="https://discord.gg/bs7EjRJekb"
              target="_blank"
              rel="noopener noreferrer"
              className="mt-5 w-full py-3 bg-[#5865F2] hover:bg-[#4752C4] text-white font-orbitron font-bold text-xs rounded-lg flex items-center justify-center transition-colors"
            >
              CONSULTAR NO DISCORD DPDK
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};