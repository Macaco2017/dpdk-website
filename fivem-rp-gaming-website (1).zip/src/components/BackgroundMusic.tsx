import React, { useEffect, useRef, useState } from 'react';
import { Music, Pause, Play, Volume2, VolumeX } from 'lucide-react';

const MUSIC_URL = 'https://cdn.discordapp.com/attachments/1487220915946258442/1509182523865825340/DPDK.mp3?ex=6a183f40&is=6a16edc0&hm=d0846e4491c7e5b88f7292b9896d75f444306c0237a4bd18a91f43c569eb10f8&';

export const BackgroundMusic: React.FC = () => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [needsInteraction, setNeedsInteraction] = useState(false);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    audio.volume = 0.28;

    audio.play()
      .then(() => {
        setIsPlaying(true);
        setNeedsInteraction(false);
      })
      .catch(() => {
        // Browsers normally block autoplay with sound until the first user click.
        setNeedsInteraction(true);
      });
  }, []);

  const togglePlay = async () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
      return;
    }

    try {
      await audio.play();
      setIsPlaying(true);
      setNeedsInteraction(false);
    } catch {
      setNeedsInteraction(true);
    }
  };

  const toggleMute = () => {
    const audio = audioRef.current;
    if (!audio) return;

    audio.muted = !audio.muted;
    setIsMuted(audio.muted);
  };

  return (
    <>
      <audio ref={audioRef} src={MUSIC_URL} loop preload="auto" />

      <div className="fixed bottom-4 right-4 z-[80] flex items-center gap-2 rounded-2xl border border-white/10 bg-[#09090f]/90 px-3 py-2 shadow-2xl backdrop-blur-md">
        <div className="hidden sm:flex items-center gap-2 pr-2 border-r border-white/10">
          <Music className="w-4 h-4 text-blue-400" />
          <span className="text-[11px] font-rajdhani font-bold text-gray-300 uppercase tracking-wider">
            {needsInteraction ? 'Clica para activar música' : 'Música do site'}
          </span>
        </div>

        <button
          onClick={togglePlay}
          className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center hover:bg-blue-500"
          title={isPlaying ? 'Pausar música' : 'Tocar música'}
        >
          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
        </button>

        <button
          onClick={toggleMute}
          className="w-9 h-9 rounded-xl bg-white/5 text-gray-300 flex items-center justify-center hover:bg-white/10 hover:text-white"
          title={isMuted ? 'Activar som' : 'Silenciar'}
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>
      </div>
    </>
  );
};