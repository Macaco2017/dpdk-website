import React, { useState } from 'react';
import { Crown, ShieldCheck, GraduationCap, Scale, ChevronRight } from 'lucide-react';
import { DPDKLogo } from './DPDKLogo';

interface RankTier {
  level: string;
  ranks: string[];
  description: string;
  color: string;
  width: string;
}

const HIERARCHY: RankTier[] = [
  {
    level: 'Comando Estratégico',
    ranks: ['Comandante-Geral', 'Vice-Comandante'],
    description: 'Define doutrina, aprova operações críticas, gere promoções superiores e representa a DPDK perante a administração da cidade.',
    color: 'from-orange-500 to-amber-500',
    width: 'lg:w-[38%]'
  },
  {
    level: 'Comando Operacional',
    ranks: ['Superintendente', 'Intendente', 'Comissário'],
    description: 'Coordena divisões, autoriza mandados, supervisiona grandes intervenções e garante que os protocolos são cumpridos.',
    color: 'from-blue-500 to-cyan-500',
    width: 'lg:w-[52%]'
  },
  {
    level: 'Oficiais de Linha',
    ranks: ['Subcomissário', 'Chefe Principal', 'Chefe'],
    description: 'Lidera patrulhas, forma novos elementos, acompanha ocorrências complexas e reporta directamente ao comando operacional.',
    color: 'from-cyan-500 to-blue-700',
    width: 'lg:w-[68%]'
  },
  {
    level: 'Execução Policial',
    ranks: ['Agente Principal', 'Agente de 1.ª Classe', 'Agente'],
    description: 'Realiza patrulhamento, abordagens, detenções, recolha de prova e resposta inicial a chamadas de emergência.',
    color: 'from-slate-500 to-blue-900',
    width: 'lg:w-[84%]'
  },
  {
    level: 'Formação',
    ranks: ['Cadete', 'Recruta'],
    description: 'Fase de avaliação. Aprende códigos rádio, escalada de força, legislação RP, condução operacional e conduta em ocorrências.',
    color: 'from-zinc-600 to-zinc-800',
    width: 'lg:w-full'
  }
];

const PROMOTION_RULES = [
  'Presença regular em patrulha e briefings.',
  'Boa comunicação via rádio e respeito pela cadeia de comando.',
  'Uso proporcional da força e boa gestão de provas.',
  'Relatórios completos após intervenções relevantes.',
  'Conduta exemplar dentro e fora de serviço.'
];

export const FleetArsenal: React.FC = () => {
  const [activeTier, setActiveTier] = useState<RankTier>(HIERARCHY[0]);

  return (
    <section id="frota" className="py-20 bg-[#050508] relative border-t border-blue-900/20 overflow-hidden">
      <div className="absolute top-1/4 left-10 w-96 h-96 bg-cyan-600/5 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-orange-500/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-14 motion-reveal">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-blue-950/60 border border-blue-800/60 mb-3">
            <Crown className="w-3.5 h-3.5 text-orange-400" />
            <span className="text-[10px] font-orbitron font-bold text-blue-400 uppercase tracking-widest">
              Estrutura Interna
            </span>
          </div>
          <h2 className="font-orbitron font-black text-3xl sm:text-4xl text-white tracking-tight motion-text">
            HIERARQUIA <span className="text-orange-400 text-glow-blue">DPDK</span>
          </h2>
          <p className="font-inter text-gray-400 mt-2 text-sm sm:text-base kinetic-panel rounded-xl p-3 border border-white/5 bg-black/20">
            A progressão dentro da polícia segue mérito, disciplina e responsabilidade. Cada patente tem deveres claros para preservar a qualidade do RP e a autoridade operacional.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-7 space-y-3">
            {HIERARCHY.map((tier, index) => {
              const isActive = activeTier.level === tier.level;
              return (
                <button
                  key={tier.level}
                  onClick={() => setActiveTier(tier)}
                  className={`mx-auto block ${tier.width} w-full text-left transition-all duration-500 cursor-pointer motion-reveal`}
                  style={{ animationDelay: `${index * 90}ms` }}
                >
                  <div className={`relative overflow-hidden rounded-xl border p-4 holo-card ${
                    isActive ? 'border-orange-400/70 bg-white/[0.06] glow-amber' : 'border-white/10 bg-white/[0.025] hover:bg-white/[0.045]'
                  }`}>
                    <div className={`absolute inset-y-0 left-0 w-1.5 bg-gradient-to-b ${tier.color}`} />
                    <div className="flex items-center justify-between gap-4 pl-2">
                      <div>
                        <span className="text-[10px] font-orbitron text-gray-500 uppercase tracking-wider">Nível {index + 1}</span>
                        <h3 className="font-orbitron font-bold text-white text-sm sm:text-base mt-0.5">{tier.level}</h3>
                        <div className="flex flex-wrap gap-1.5 mt-2">
                          {tier.ranks.map((rank) => (
                            <span key={rank} className="text-[10px] font-rajdhani font-bold text-gray-200 bg-black/35 border border-white/10 px-2 py-0.5 rounded">
                              {rank}
                            </span>
                          ))}
                        </div>
                      </div>
                      <ChevronRight className={`w-5 h-5 shrink-0 ${isActive ? 'text-orange-400' : 'text-gray-600'}`} />
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="lg:col-span-5 bg-[#09090f] border border-white/10 rounded-2xl p-6 sticky top-28 sweep-line overflow-hidden holo-card">
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-5">
                <div className="w-12 h-12 rounded-xl bg-black/50 border border-orange-400/30 flex items-center justify-center overflow-hidden">
                  <DPDKLogo className="w-full h-full p-1 holo-image" />
                </div>
                <div>
                  <span className="text-[10px] font-orbitron text-orange-300 uppercase tracking-widest">Patente em foco</span>
                  <h3 className="font-orbitron font-black text-xl text-white motion-text">{activeTier.level}</h3>
                </div>
              </div>

              <p className="text-sm text-gray-300 leading-relaxed mb-5">{activeTier.description}</p>

              <div className="space-y-2 mb-6">
                {activeTier.ranks.map((rank) => (
                  <div key={rank} className="bg-black/35 border border-white/5 rounded-lg px-3 py-2 flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-blue-400" />
                    <span className="text-xs font-rajdhani font-bold text-white">{rank}</span>
                  </div>
                ))}
              </div>

              <div className="pt-4 border-t border-white/5">
                <span className="text-[10px] font-orbitron text-gray-500 uppercase tracking-wider block mb-2">Critérios de promoção</span>
                <div className="space-y-2">
                  {PROMOTION_RULES.map((rule) => (
                    <div key={rule} className="flex items-start gap-2 text-xs text-gray-300">
                      <Scale className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                      <span>{rule}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 bg-blue-950/25 border border-blue-800/40 rounded-xl p-4 flex gap-3">
                <GraduationCap className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                <p className="text-xs text-gray-300 leading-relaxed">
                  A subida de patente nunca é automática. O comando avalia postura, maturidade, qualidade de RP, relatórios e capacidade de liderar situações sob pressão.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};