import React, { useState } from 'react';

interface DPDKLogoProps {
  className?: string;
}

export const DPDKLogo: React.FC<DPDKLogoProps> = ({ className = '' }) => {
  const [useFallback, setUseFallback] = useState(false);

  if (!useFallback) {
    return (
      <img
        src="/images/logo-dpdk.png"
        alt="Logotipo DPDK Darkside RP"
        className={className}
        onError={() => setUseFallback(true)}
      />
    );
  }

  return (
    <svg
      viewBox="0 0 900 1100"
      className={className}
      role="img"
      aria-label="Logotipo DPDK Darkside RP"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path d="M51 35H849V600C849 826 694 1000 450 1070C206 1000 51 826 51 600V35Z" fill="#ff9f1f" />
      <path d="M86 70H814V586C814 792 671 949 450 1015C229 949 86 792 86 586V70Z" fill="#d9e2ec" />
      <path d="M114 102H786V575C786 765 656 912 450 977C244 912 114 765 114 575V102Z" fill="#050506" />

      <path d="M155 278H274L304 586L205 592L155 278Z" fill="#f4f7fb" opacity="0.82" />
      <path d="M745 278H626L596 586L695 592L745 278Z" fill="#f4f7fb" opacity="0.82" />
      <path d="M230 314H670V610C670 758 575 869 450 920C325 869 230 758 230 610V314Z" fill="#050506" stroke="#e6edf5" strokeWidth="16" />

      <text x="450" y="176" textAnchor="middle" fill="#f5f7fb" fontFamily="Orbitron, Arial Black, sans-serif" fontSize="44" fontWeight="800" letterSpacing="6">DEPARTAMENTO</text>
      <text x="450" y="270" textAnchor="middle" fill="#ffffff" fontFamily="Orbitron, Arial Black, sans-serif" fontSize="100" fontWeight="900" letterSpacing="7">POLICIA</text>

      <g filter="drop-shadow(0 0 14px rgba(255,159,31,0.65))">
        <path d="M450 352C360 408 312 506 294 616C335 560 385 542 450 542C515 542 565 560 606 616C588 506 540 408 450 352Z" fill="#111217" stroke="#fff5bd" strokeWidth="7" />
        <path d="M300 609C343 545 376 512 450 512C524 512 557 545 600 609C641 646 659 703 674 760C601 816 531 848 450 861C369 848 299 816 226 760C241 703 259 646 300 609Z" fill="#050507" stroke="#ff9f1f" strokeWidth="8" />
        <path d="M400 548C345 592 323 657 316 728C349 686 387 673 450 673C513 673 551 686 584 728C577 657 555 592 500 548C481 580 468 598 450 598C432 598 419 580 400 548Z" fill="#17181d" />
        <path d="M370 596C392 586 418 592 430 609C406 617 381 615 357 607C360 602 364 599 370 596Z" fill="#ffb21f" />
        <path d="M530 596C508 586 482 592 470 609C494 617 519 615 543 607C540 602 536 599 530 596Z" fill="#ffb21f" />
      </g>

      <text x="450" y="705" textAnchor="middle" fill="#ffffff" fontFamily="Georgia, serif" fontSize="82" fontWeight="700" letterSpacing="2" stroke="#050506" strokeWidth="3">Darkside</text>
      <text x="450" y="790" textAnchor="middle" fill="#ffffff" fontFamily="Georgia, serif" fontSize="78" fontWeight="700" letterSpacing="4" stroke="#050506" strokeWidth="3">RP</text>
      <path d="M450 835L478 870L450 905L422 870L450 835Z" fill="#ffb21f" />
      <text x="450" y="958" textAnchor="middle" fill="#ffffff" fontFamily="Orbitron, Arial Black, sans-serif" fontSize="52" fontWeight="900" letterSpacing="5">DPDK</text>
    </svg>
  );
};