import React from 'react';
import { Terminal, ArrowUp, ShieldAlert, Heart } from 'lucide-react';
import { DPDKLogo } from './DPDKLogo';

interface FooterProps {
  setActiveTab: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ setActiveTab }) => {
  
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNav = (id: string) => {
    setActiveTab(id);
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#030305] text-gray-400 border-t border-white/5 relative overflow-hidden">
      
      {/* Subtle top laser border */}
      <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-blue-500/30 to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-8">
        
        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 pb-12 border-b border-white/5">
          
          {/* Col 1: Branding */}
          <div className="lg:col-span-4 space-y-4">
            
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-black/60 flex items-center justify-center border border-orange-400/30 shadow overflow-hidden">
                <DPDKLogo className="h-full w-full p-0.5" />
              </div>
              <span className="font-orbitron font-black text-base tracking-wider text-white">
                DP<span className="text-blue-500">DK</span> // DARKSIDE
              </span>
            </div>

            <p className="font-inter text-xs text-gray-400 leading-relaxed">
              A corporação oficial responsável pelo patrulhamento táctico e ostensivo do servidor <strong className="text-white">Darkside RP</strong>. Disciplina, inteligência e viaturas de elite.
            </p>

            {/* Direct Console copy */}
            <div className="pt-2">
              <span className="text-[10px] font-orbitron text-gray-500 block uppercase mb-1">
                Ligar ao Servidor
              </span>
              <code className="text-xs font-mono text-cyan-400 bg-white/5 px-2.5 py-1 rounded border border-white/5 select-all">
                connect jogar.darksiderp.com
              </code>
            </div>

          </div>

          {/* Col 2: Navigation */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="font-orbitron font-bold text-xs text-white uppercase tracking-wider">
              Grupamentos
            </h4>
            <ul className="space-y-2 text-xs font-rajdhani font-medium">
              <li>
                <button onClick={() => handleNav('inicio')} className="hover:text-white transition-colors cursor-pointer">
                  QG Central
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('sobre')} className="hover:text-white transition-colors cursor-pointer">
                  Departamento
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('frota')} className="hover:text-white transition-colors cursor-pointer">
                  Hierarquia
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('intervencoes')} className="hover:text-white transition-colors cursor-pointer">
                  Intervenções
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('cad')} className="hover:text-white transition-colors cursor-pointer">
                  Sistema CAD
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('recrutamento')} className="text-blue-400 hover:text-blue-300 transition-colors cursor-pointer">
                  Candidatura
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Guidelines */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="font-orbitron font-bold text-xs text-white uppercase tracking-wider">
              Diretrizes DPDK
            </h4>
            <ul className="space-y-2 text-xs font-inter">
              <li>
                <a href="#codigo" onClick={(e) => { e.preventDefault(); alert("O Código Penal e as regras de actuação da DPDK estão fixados no nosso Discord Oficial."); }} className="hover:text-white transition-colors">
                  Código Penal de Darkside
                </a>
              </li>
              <li>
                <a href="#hierarquia" onClick={(e) => { e.preventDefault(); alert("Hierarquia: Soldado > Cabo > Sargento > Tenente > Capitão > Major > Coronel > Comandante Geral."); }} className="hover:text-white transition-colors">
                  Hierarquia & Patentes
                </a>
              </li>
              <li>
                <a href="#corregedoria" onClick={(e) => { e.preventDefault(); alert("Para reportar má conduta de oficiais, abre um ticket na Corregedoria do Discord."); }} className="hover:text-white transition-colors">
                  Corregedoria (Denúncias)
                </a>
              </li>
              <li>
                <a href="#treinamento" onClick={(e) => { e.preventDefault(); alert("Os treinos tácticos decorrem todas as terças e quintas às 20h na pista de testes."); }} className="hover:text-white transition-colors text-cyan-400">
                  Agenda de Treinos
                </a>
              </li>
            </ul>
          </div>

          {/* Col 4: Discord CTA */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="font-orbitron font-bold text-xs text-white uppercase tracking-wider">
              Central de Comunicação
            </h4>
            
            <div className="bg-[#09090f] border border-white/5 rounded-xl p-3 space-y-2.5 holo-card overflow-hidden">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-[#5865F2]" />
                <span className="text-xs font-orbitron font-bold text-gray-200">DISCORDS OFICIAIS</span>
              </div>
              <p className="text-[11px] text-gray-400 leading-tight">
                Usa o Discord da DPDK para candidaturas e assuntos policiais. Usa o Discord da cidade para regras gerais, suporte e anúncios da administração.
              </p>
              <a
                href="https://discord.gg/bs7EjRJekb"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2 bg-[#5865F2] hover:bg-[#4752C4] text-white font-rajdhani font-bold text-xs rounded block text-center transition-colors shadow"
              >
                DISCORD POLÍCIA DPDK
              </a>
              <a
                href="https://discord.gg/darksiderp"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2 bg-white/5 hover:bg-white/10 text-gray-200 border border-white/10 font-rajdhani font-bold text-xs rounded block text-center transition-colors"
              >
                DISCORD CIDADE DARKSIDE
              </a>
            </div>

          </div>

        </div>

        {/* Bottom Disclaimers */}
        <div className="pt-8 flex flex-col lg:flex-row items-center justify-between gap-6 text-[11px]">
          
          <div className="flex items-start gap-2 max-w-3xl text-gray-500">
            <ShieldAlert className="w-4 h-4 text-gray-600 shrink-0 mt-0.5" />
            <p className="leading-tight">
              <strong className="text-gray-400">Aviso:</strong> Este site é uma interface de Roleplay imersiva desenvolvida para o departamento <strong className="text-gray-300">DPDK</strong> do servidor <strong className="text-gray-300">Darkside RP</strong>. Todas as referências a crimes, viaturas e armamentos são simulações em ambiente de jogo (FiveM).
            </p>
          </div>

          <div className="shrink-0 flex flex-col items-center lg:items-end gap-2">
            <div className="flex items-center gap-1 text-gray-400">
              <span>Desenvolvido com</span>
              <Heart className="w-3 h-3 text-red-500 fill-red-500" />
              <span>para o Darkside RP</span>
            </div>
            <span className="text-gray-600">
              &copy; {new Date().getFullYear()} DPDK. Todos os direitos reservados.
            </span>
          </div>

        </div>

        {/* Scroll to Top */}
        <div className="mt-8 flex justify-center">
          <button
            onClick={scrollToTop}
            className="p-2.5 rounded-full bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white border border-white/10 transition-all cursor-pointer"
            title="Voltar ao Topo"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>

      </div>
    </footer>
  );
};
