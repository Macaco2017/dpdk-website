import React, { useState } from 'react';
import { CheckCircle, ChevronDown, ChevronUp, FileText, Image, KeyRound, LogOut, Pencil, PlusCircle, ShieldAlert, Trash2 } from 'lucide-react';

interface Intervention {
  id: string;
  title: string;
  date: string;
  location: string;
  type: 'Apreensão' | 'Perseguição' | 'Resgate' | 'Operação';
  status: 'Concluído' | 'Sob Investigação';
  summary: string;
  seizedItems: string[];
  image: string;
  videoUrl?: string;
}

const emptyForm = {
  title: '',
  location: '',
  type: 'Operação' as Intervention['type'],
  status: 'Concluído' as Intervention['status'],
  summary: '',
  seized: '',
  image: '',
  video: ''
};

const ADMIN_PASSWORD = 'DPDK2026DARKSIDE';

export const InterventionsFeed: React.FC = () => {
  const [interventions, setInterventions] = useState<Intervention[]>([]);
  const [filter, setFilter] = useState('Todos');
  const [expandedId, setExpandedId] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [adminError, setAdminError] = useState('');
  const [isAdmin, setIsAdmin] = useState(() => {
    if (typeof window === 'undefined') return false;
    return window.localStorage.getItem('dpdk_admin_unlocked') === 'true';
  });
  const [form, setForm] = useState(emptyForm);

  const filteredItems = interventions.filter((item) => filter === 'Todos' || item.type === filter);

  const resetForm = () => {
    setForm(emptyForm);
    setEditingId(null);
    setShowForm(false);
  };

  const unlockAdmin = (event: React.FormEvent) => {
    event.preventDefault();

    if (adminPassword === ADMIN_PASSWORD) {
      setIsAdmin(true);
      setAdminError('');
      setAdminPassword('');
      if (typeof window !== 'undefined') {
        window.localStorage.setItem('dpdk_admin_unlocked', 'true');
      }
      return;
    }

    setAdminError('Palavra-passe incorrecta.');
  };

  const logoutAdmin = () => {
    setIsAdmin(false);
    resetForm();
    if (typeof window !== 'undefined') {
      window.localStorage.removeItem('dpdk_admin_unlocked');
    }
  };

  const openCreate = () => {
    setForm(emptyForm);
    setEditingId(null);
    setShowForm(true);
  };

  const openEdit = (item: Intervention) => {
    setForm({
      title: item.title,
      location: item.location,
      type: item.type,
      status: item.status,
      summary: item.summary,
      seized: item.seizedItems.join(', '),
      image: item.image,
      video: item.videoUrl || ''
    });
    setEditingId(item.id);
    setShowForm(true);
    setExpandedId(item.id);
  };

  const removeIntervention = (id: string) => {
    setInterventions((current) => current.filter((item) => item.id !== id));
    if (expandedId === id) setExpandedId('');
    setSuccessMsg('Intervenção apagada com sucesso.');
    setTimeout(() => setSuccessMsg(''), 3000);
  };

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    if (!form.title || !form.summary) return;

    const payload: Intervention = {
      id: editingId || `op-${Date.now()}`,
      title: form.title,
      date: editingId ? 'Actualizado agora' : 'Agora mesmo',
      location: form.location || 'Sector Patrulhado',
      type: form.type,
      status: form.status,
      summary: form.summary,
      seizedItems: form.seized ? form.seized.split(',').map((item) => item.trim()).filter(Boolean) : ['Nenhum item listado'],
      image: form.image || '',
      videoUrl: form.video || undefined
    };

    setInterventions((current) => {
      if (editingId) return current.map((item) => item.id === editingId ? payload : item);
      return [payload, ...current];
    });

    setExpandedId(payload.id);
    setSuccessMsg(editingId ? 'Intervenção modificada com sucesso.' : 'Intervenção publicada com sucesso.');
    setTimeout(() => setSuccessMsg(''), 3000);
    resetForm();
  };

  return (
    <section id="intervencoes" className="py-20 bg-[#050508]/80 relative border-t border-blue-900/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-12 kinetic-panel rounded-2xl p-4 motion-reveal">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-red-950/60 border border-red-800/60 mb-3 animate-pulse-glow">
            <ShieldAlert className="w-3.5 h-3.5 text-red-400" />
            <span className="text-[10px] font-orbitron font-bold text-red-400 uppercase tracking-widest">Anúncios & Registos Públicos</span>
          </div>
          <h2 className="font-orbitron font-black text-3xl sm:text-4xl text-white tracking-tight motion-text glitch-text">
            GESTÃO DE <span className="text-red-500 text-glow">INTERVENÇÕES</span>
          </h2>
          <p className="font-inter text-gray-400 mt-2 text-sm sm:text-base">
            Podes criar, modificar ou apagar intervenções. Os relatórios antigos foram removidos para começares com o painel limpo.
          </p>

          <div className="flex flex-wrap items-center justify-between gap-4 mt-8 pt-4 border-t border-white/5">
            <div className="flex flex-wrap gap-1.5">
              {['Todos', 'Operação', 'Perseguição', 'Apreensão', 'Resgate'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setFilter(cat)}
                  className={`px-3 py-1 rounded text-xs font-rajdhani font-bold cursor-pointer ${filter === cat ? 'bg-blue-600 text-white' : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white'}`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {isAdmin && (
              <button
                onClick={showForm ? resetForm : openCreate}
                className={`px-4 py-2 rounded-lg font-orbitron font-bold text-xs flex items-center gap-2 cursor-pointer ${showForm ? 'bg-red-950 text-red-400 border border-red-800' : 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-md'}`}
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>{showForm ? 'CANCELAR' : 'NOVA INTERVENÇÃO'}</span>
              </button>
            )}
          </div>
        </div>

        <div className="mb-8 rounded-2xl border border-white/10 bg-[#09090f]/90 p-4">
          {isAdmin ? (
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-2 text-sm text-emerald-300">
                <CheckCircle className="h-4 w-4" />
                <span className="font-rajdhani font-bold">Modo admin activo. Podes criar, modificar e apagar intervenções.</span>
              </div>
              <button
                onClick={logoutAdmin}
                className="inline-flex items-center justify-center gap-2 rounded-lg border border-red-800 bg-red-950/40 px-4 py-2 text-xs font-orbitron font-bold text-red-300"
              >
                <LogOut className="h-4 w-4" />
                Sair do admin
              </button>
            </div>
          ) : (
            <form onSubmit={unlockAdmin} className="grid grid-cols-1 gap-3 md:grid-cols-[1fr_auto] md:items-end">
              <div>
                <label className="mb-1.5 flex items-center gap-2 text-xs font-orbitron uppercase tracking-wider text-blue-300">
                  <KeyRound className="h-4 w-4" />
                  Acesso admin para gerir intervenções
                </label>
                <input
                  type="password"
                  value={adminPassword}
                  onChange={(event) => setAdminPassword(event.target.value)}
                  placeholder="Palavra-passe de admin"
                  className="w-full rounded-xl border border-white/10 bg-black/50 px-4 py-3 text-sm text-white outline-none focus:border-blue-500"
                />
                {adminError && <p className="mt-1 text-xs text-red-300">{adminError}</p>}
              </div>
              <button
                type="submit"
                className="rounded-xl bg-blue-600 px-5 py-3 text-xs font-orbitron font-bold text-white hover:bg-blue-500"
              >
                Entrar como admin
              </button>
            </form>
          )}
        </div>

        {isAdmin && showForm && (
          <div className="mb-12 bg-[#09090f] border-2 border-blue-500/40 rounded-2xl p-6 sm:p-8 relative holo-card overflow-hidden">
            <div className="flex items-center gap-2 mb-6 pb-3 border-b border-white/5">
              <FileText className="w-5 h-5 text-blue-400" />
              <div>
                <h3 className="font-orbitron font-bold text-base text-white">{editingId ? 'MODIFICAR INTERVENÇÃO' : 'NOVA INTERVENÇÃO'}</h3>
                <span className="text-[11px] text-gray-400 font-inter block">Preenche os campos e guarda o registo operacional.</span>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input required placeholder="Título da operação" value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} className="bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
                <input placeholder="Localização" value={form.location} onChange={(event) => setForm({ ...form, location: event.target.value })} className="bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
                <select value={form.type} onChange={(event) => setForm({ ...form, type: event.target.value as Intervention['type'] })} className="bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-sm text-white">
                  <option value="Operação">Operação Geral</option>
                  <option value="Perseguição">Perseguição</option>
                  <option value="Apreensão">Apreensão</option>
                  <option value="Resgate">Resgate</option>
                </select>
                <select value={form.status} onChange={(event) => setForm({ ...form, status: event.target.value as Intervention['status'] })} className="bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-sm text-white">
                  <option value="Concluído">Concluído</option>
                  <option value="Sob Investigação">Sob Investigação</option>
                </select>
                <input placeholder="Itens apreendidos separados por vírgula" value={form.seized} onChange={(event) => setForm({ ...form, seized: event.target.value })} className="md:col-span-2 bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
                <input placeholder="URL da fotografia" value={form.image} onChange={(event) => setForm({ ...form, image: event.target.value })} className="bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
                <input placeholder="URL do vídeo MP4" value={form.video} onChange={(event) => setForm({ ...form, video: event.target.value })} className="bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-sm text-white" />
              </div>

              <textarea required rows={4} placeholder="Resumo do relatório" value={form.summary} onChange={(event) => setForm({ ...form, summary: event.target.value })} className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-sm text-white" />

              <div className="flex justify-end gap-3">
                <button type="button" onClick={resetForm} className="px-5 py-3 bg-white/5 text-gray-300 border border-white/10 rounded-lg font-rajdhani font-bold text-xs">CANCELAR</button>
                <button type="submit" className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-orbitron font-bold text-xs rounded-lg shadow-md">
                  {editingId ? 'GUARDAR ALTERAÇÕES' : 'PUBLICAR'}
                </button>
              </div>
            </form>
          </div>
        )}

        {successMsg && (
          <div className="mb-8 bg-emerald-950/80 border border-emerald-500 text-emerald-300 p-4 rounded-xl flex items-center gap-3">
            <CheckCircle className="w-5 h-5 shrink-0" />
            <p className="text-xs font-rajdhani font-bold">{successMsg}</p>
          </div>
        )}

        <div className="space-y-6">
          {filteredItems.map((item) => {
            const isExpanded = expandedId === item.id;
            return (
              <div key={item.id} className="bg-[#09090f] border border-white/10 rounded-xl overflow-hidden holo-card">
                <div className="p-4 sm:p-5 bg-black/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <button onClick={() => setExpandedId(isExpanded ? '' : item.id)} className="text-left flex-1 cursor-pointer">
                    <span className="text-[10px] font-orbitron font-bold px-2 py-0.5 rounded border uppercase tracking-wider bg-blue-950 text-blue-400 border-blue-800">{item.type}</span>
                    <h3 className="font-orbitron font-bold text-base text-white mt-2">{item.title}</h3>
                    <div className="flex items-center gap-2 text-xs text-gray-500 font-rajdhani mt-0.5">
                      <span>{item.date}</span><span>|</span><span>{item.location}</span>
                    </div>
                  </button>

                  <div className="flex items-center gap-2 self-end sm:self-auto">
                    {isAdmin && (
                      <>
                        <button onClick={() => openEdit(item)} className="px-3 py-2 rounded-lg bg-white/5 text-blue-300 border border-white/10 flex items-center gap-1 text-xs font-rajdhani font-bold"><Pencil className="w-3.5 h-3.5" /> Modificar</button>
                        <button onClick={() => removeIntervention(item.id)} className="px-3 py-2 rounded-lg bg-red-950/40 text-red-300 border border-red-800 flex items-center gap-1 text-xs font-rajdhani font-bold"><Trash2 className="w-3.5 h-3.5" /> Apagar</button>
                      </>
                    )}
                    <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-gray-400">{isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}</div>
                  </div>
                </div>

                {isExpanded && (
                  <div className="p-5 sm:p-6 border-t border-white/5 bg-gradient-to-b from-transparent to-black/20">
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                      <div className="lg:col-span-6 space-y-4">
                        <p className="font-inter text-sm text-gray-200 leading-relaxed">{item.summary}</p>
                        <div className="space-y-1.5">
                          {item.seizedItems.map((seized) => <div key={seized} className="text-xs text-gray-300 bg-black/40 px-3 py-1.5 rounded border border-white/5">{seized}</div>)}
                        </div>
                      </div>
                      <div className="lg:col-span-6 rounded-xl overflow-hidden border border-white/10 bg-black h-48 sm:h-64 flex items-center justify-center">
                        {item.videoUrl ? <video src={item.videoUrl} controls className="w-full h-full object-cover" /> : item.image ? <img src={item.image} alt={item.title} className="w-full h-full object-cover" /> : <div className="text-xs text-gray-500 flex items-center gap-2"><Image className="w-4 h-4" /> Sem multimédia anexado</div>}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {filteredItems.length === 0 && (
            <div className="text-center py-14 bg-white/[0.01] rounded-xl border border-white/5">
              <p className="text-sm text-gray-400 font-rajdhani">Ainda não existem intervenções publicadas. Usa “Nova Intervenção” para criar o primeiro registo.</p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};