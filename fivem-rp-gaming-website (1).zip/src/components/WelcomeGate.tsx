import React from 'react';
import { ChevronRight, ShieldCheck } from 'lucide-react';
import { DPDKLogo } from './DPDKLogo';

interface WelcomeGateProps {
  onContinue: () => void;
}

export const WelcomeGate: React.FC<WelcomeGateProps> = ({ onContinue }) => {
  return (
    <section className="fixed inset-0 z-[120] flex items-center justify-center overflow-hidden bg-[#050508] px-4">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_35%,rgba(37,99,235,0.25),transparent_34%),radial-gradient(circle_at_70%_70%,rgba(236,72,153,0.18),transparent_30%),linear-gradient(135deg,#050508_0%,#090719_55%,#050508_100%)]" />
      <div className="absolute inset-0 scanlines opacity-40" />

      <div className="relative z-10 w-full max-w-3xl rounded-[2rem] border border-white/10 bg-[#09090f]/90 p-8 text-center shadow-[0_0_90px_rgba(37,99,235,0.25)] backdrop-blur-md">
        <div className="mx-auto mb-6 flex h-40 w-40 items-center justify-center rounded-3xl border border-blue-500/30 bg-black/40 shadow-[0_0_50px_rgba(37,99,235,0.25)] sm:h-52 sm:w-52">
          <DPDKLogo className="h-full w-full p-3 logo-hero-pulse" />
        </div>

        <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-blue-500/30 bg-blue-950/40 px-4 py-1.5">
          <ShieldCheck className="h-4 w-4 text-blue-400" />
          <span className="font-orbitron text-[10px] font-bold uppercase tracking-[0.28em] text-blue-300">
            Acesso Oficial DPDK
          </span>
        </div>

        <h1 className="font-audiowide text-3xl leading-tight text-white sm:text-5xl tracking-wide">
          Bem-vindo à Polícia <span className="neon-title-gradient">DPDK</span>
        </h1>

        <p className="mx-auto mt-4 max-w-xl font-rajdhani text-lg font-semibold leading-relaxed text-gray-300 sm:text-xl">
          Estás pronto para entrar nesta aventura e conhecer a força policial da Darkside RP?
        </p>

        <button
          onClick={onContinue}
          className="neon-button mt-8 inline-flex items-center justify-center gap-2 rounded-full px-9 py-4 font-orbitron text-sm font-bold uppercase tracking-wider text-white shadow-lg"
        >
          Continuar
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>
    </section>
  );
};