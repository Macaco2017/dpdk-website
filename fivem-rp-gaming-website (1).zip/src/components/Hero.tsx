import React from 'react';
import { BadgeCheck, ChevronRight, FileText, Shield, Siren, Star, Terminal, Users } from 'lucide-react';
import { DPDKLogo } from './DPDKLogo';

interface HeroProps {
  onGoToRecruitment: () => void;
  onGoToInterventions: () => void;
}

const HERO_FEATURES = [
  { icon: Shield, label: 'Hierarquia', value: 'Comando activo' },
  { icon: Terminal, label: 'Códigos', value: 'Rádio PT' },
  { icon: Siren, label: 'Operações', value: 'Intervenções RP' },
  { icon: BadgeCheck, label: 'Conduta', value: 'Avaliação rigorosa' }
];

export const Hero: React.FC<HeroProps> = ({ onGoToRecruitment, onGoToInterventions }) => {
  return (
    <section id="inicio" className="relative overflow-hidden pt-28 pb-10 px-4 sm:px-6 lg:px-8">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_72%_38%,rgba(247,37,212,0.22),transparent_34%),radial-gradient(circle_at_35%_10%,rgba(0,194,255,0.18),transparent_28%),linear-gradient(135deg,#080716_0%,#0d0822_48%,#090719_100%)]" />
      <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-[#080716] to-transparent" />

      <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center neon-card rounded-[2rem] p-6 sm:p-8 lg:p-10 overflow-hidden">
        <div className="absolute left-8 top-8 h-28 w-28 rounded-full bg-fuchsia-500/20 blur-3xl" />
        <div className="absolute right-8 bottom-8 h-36 w-36 rounded-full bg-cyan-500/20 blur-3xl" />

        <div className="lg:col-span-7 relative z-10 motion-reveal">
          <div className="inline-flex items-center gap-2 rounded-full bg-white/5 border border-white/10 px-3 py-1.5 mb-6">
            <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
            <span className="font-orbitron text-[10px] tracking-widest text-fuchsia-300 uppercase">Departamento de Polícia Darkside RP</span>
          </div>

          <h1 className="font-orbitron font-black text-4xl sm:text-6xl lg:text-7xl leading-[0.95] tracking-tight text-white motion-text">
            ENTRA NA <br />
            <span className="neon-title-gradient">DPDK</span>
          </h1>

          <p className="mt-6 max-w-xl text-base sm:text-lg text-gray-300 leading-relaxed">
            Portal oficial da polícia DPDK: candidaturas, hierarquia, códigos rádio e intervenções. Uma interface central para quem quer fazer RP policial sério no servidor Darkside RP.
          </p>

          <div className="mt-8 flex flex-wrap gap-4">
            <button
              onClick={onGoToRecruitment}
              className="neon-button px-7 py-3.5 rounded-full text-white font-orbitron font-bold text-sm flex items-center gap-2 cursor-pointer"
            >
              <FileText className="w-4 h-4" />
              Fazer Candidatura
              <ChevronRight className="w-4 h-4" />
            </button>

            <button
              onClick={onGoToInterventions}
              className="px-7 py-3.5 rounded-full bg-white/7 hover:bg-white/10 border border-white/10 text-white font-rajdhani font-bold text-sm flex items-center gap-2 cursor-pointer"
            >
              Ver Intervenções
            </button>
          </div>

          <div className="mt-6 flex flex-wrap gap-5 text-[11px] text-gray-400 font-rajdhani font-bold uppercase tracking-wider">
            <span>Disciplina</span>
            <span>Hierarquia</span>
            <span>Cadeia de Comando</span>
          </div>
        </div>

        <div className="lg:col-span-5 relative z-10 motion-float">
          <div className="relative mx-auto max-w-md aspect-square neon-orb rounded-full flex items-center justify-center">
            <div className="absolute inset-8 rounded-full border border-fuchsia-400/25" />
            <div className="absolute inset-16 rounded-full border border-cyan-400/20" />
            <DPDKLogo className="relative z-10 h-[78%] w-[78%] drop-shadow-[0_0_40px_rgba(247,37,212,0.32)] logo-hero-pulse" />
          </div>

          <div className="grid grid-cols-2 gap-3 mt-5">
            {HERO_FEATURES.map((item) => {
              const Icon = item.icon;
              return (
                <div key={item.label} className="neon-panel rounded-2xl p-4 text-center">
                  <Icon className="w-5 h-5 text-fuchsia-300 mx-auto mb-2" />
                  <span className="block font-orbitron text-[10px] uppercase text-white">{item.label}</span>
                  <span className="block text-[11px] text-gray-400 mt-1">{item.value}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="relative z-10 brand-strip mt-8 px-6 py-5 rounded-2xl flex flex-wrap items-center justify-center gap-8 text-xs text-gray-400 font-orbitron uppercase tracking-widest">
        <span>Darkside RP</span>
        <span>DPDK</span>
        <span>Códigos Rádio PT</span>
        <span>Questionário RP</span>
        <span className="flex items-center gap-1"><Users className="w-4 h-4 text-fuchsia-300" /> Recrutamento</span>
      </div>
    </section>
  );
};