import React, { useState } from 'react';
import { Shield, Video, Image, UserCheck } from 'lucide-react';

interface Division {
  id: string;
  name: string;
  code: string;
  description: string;
  role: string;
  equipment: string[];
  image: string;
  videoUrl?: string;
  color: string;
}

const DIVISIONS: Division[] = [
  {
    id: 'rota',
    name: 'Rondas Ostensivas Tácticas (ROTA)',
    code: 'DIV-01',
    description: 'A espinha dorsal do patrulhamento da DPDK. Actua com viaturas pesadas, forte poder de fogo e patrulhamento de saturação nas zonas com maior índice criminal.',
    role: 'Patrulhamento Ostensivo & Resposta Rápida',
    equipment: ['Carabina M4A1', 'Caçadeira Pump-Action', 'Colete Balístico Nível III-A', 'Viatura SUV Interceptadora'],
    image: 'https://images.pexels.com/photos/4267620/pexels-photo-4267620.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=800',
    videoUrl: 'https://videos.pexels.com/video-files/7714379/7714379-uhd_3840_2160_30fps.mp4',
    color: 'border-blue-500 text-blue-400'
  },
  {
    id: 'gate',
    name: 'Grupo de Acções Tácticas Especiais (GATE)',
    code: 'DIV-02',
    description: 'A elite operacional para situações extremas. É accionada exclusivamente para libertação de cativeiros, assaltos a banco com reféns e cumprimento de mandados de alto risco.',
    role: 'Invasões Tácticas, Atiradores de Elite & Negociação',
    equipment: ['Rifle Sniper AWP', 'Submetralhadora MP5X', 'Granadas de Luz/Som', 'Veículo Blindado Caveirão'],
    image: 'https://images.pexels.com/photos/37182286/pexels-photo-37182286.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=800',
    videoUrl: 'https://videos.pexels.com/video-files/4766221/4766221-uhd_4096_2160_24fps.mp4',
    color: 'border-red-500 text-red-400'
  },
  {
    id: 'speed',
    name: 'Divisão de Trânsito e Intercepção',
    code: 'DIV-03',
    description: 'Composta por agentes especializados em abordagens rodoviárias, controlo de tráfego, perseguições e bloqueios coordenados.',
    role: 'Controlo de Trânsito, Bloqueios & Intercepção',
    equipment: ['Pistola Five-Seven', 'Taser X26', 'Bloqueadores de Sinal GPS', 'Kit de bloqueio de via'],
    image: 'https://images.pexels.com/photos/14984574/pexels-photo-14984574.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=800',
    color: 'border-amber-500 text-amber-400'
  },
  {
    id: 'investigacao',
    name: 'Inteligência & Investigação (P2)',
    code: 'DIV-04',
    description: 'Actuam nas sombras com viaturas descaracterizadas e roupa civil. Infiltram-se em facções, monitorizam o Mercado Negro e preparam dossiês criminais.',
    role: 'Infiltração, Escuta Telefónica & Dossiês Criminais',
    equipment: ['Câmara Oculta', 'Algemas de Alta Segurança', 'Acesso à Base de Dados CAD', 'Sedan Descaracterizado'],
    image: 'https://images.pexels.com/photos/18421319/pexels-photo-18421319.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=800',
    color: 'border-cyan-500 text-cyan-400'
  }
];

export const AboutPolice: React.FC = () => {
  const [activeDiv, setActiveDiv] = useState<Division>(DIVISIONS[0]);
  const [activeMedia, setActiveMedia] = useState<'image' | 'video'>('image');

  return (
    <section id="sobre" className="py-20 bg-[#050508] relative border-t border-blue-900/20">
      
      {/* Visual background elements */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-blue-600/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 kinetic-panel rounded-2xl p-4 motion-reveal">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-blue-950/60 border border-blue-800/60 mb-3">
            <Shield className="w-3.5 h-3.5 text-blue-400" />
            <span className="text-[10px] font-orbitron font-bold text-blue-400 uppercase tracking-widest">
              Conhece a DPDK
            </span>
          </div>
          <h2 className="font-orbitron font-black text-3xl sm:text-4xl text-white tracking-tight motion-text glitch-text">
            DEPARTAMENTO DE POLÍCIA <span className="text-blue-500 text-glow-blue">DARKSIDE</span>
          </h2>
          <p className="font-inter text-gray-400 mt-3 text-sm sm:text-base leading-relaxed">
            Fundada sobre os pilares da disciplina e da táctica operacional, a <strong className="text-white">DPDK</strong> é a principal força legal do servidor. A nossa corporação está dividida em batalhões especializados para garantir que cada tipo de crime tenha a resposta adequada.
          </p>
        </div>

        {/* Workspace: Division Selector + Media Display */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Left: Division Tabs */}
          <div className="lg:col-span-5 flex flex-col gap-3 justify-center">
            <span className="text-[10px] font-orbitron text-gray-500 uppercase tracking-wider block mb-1">
              Selecciona o Grupamento
            </span>

            {DIVISIONS.map((div) => {
              const isSelected = activeDiv.id === div.id;
              return (
                <button
                  key={div.id}
                  onClick={() => {
                    setActiveDiv(div);
                    setActiveMedia('image');
                  }}
                  className={`w-full text-left p-4 rounded-xl border transition-all cursor-pointer flex items-start gap-3 holo-card overflow-hidden motion-reveal ${
                    isSelected 
                      ? 'bg-blue-950/40 border-blue-500 shadow-lg ring-1 ring-blue-500/20' 
                      : 'bg-white/[0.01] border-white/5 hover:bg-white/[0.03] hover:border-white/10'
                  }`}
                >
                  <div className={`w-8 h-8 rounded-lg bg-black/40 border flex items-center justify-center font-orbitron font-black text-xs shrink-0 mt-0.5 ${
                    isSelected ? div.color : 'border-white/10 text-gray-500'
                  }`}>
                    {div.code.replace('DIV-', '')}
                  </div>

                  <div className="grow">
                    <div className="flex items-center justify-between">
                      <h3 className={`font-orbitron font-bold text-sm ${isSelected ? 'text-white' : 'text-gray-300'}`}>
                        {div.name}
                      </h3>
                    </div>
                    <span className="text-xs font-rajdhani font-medium text-blue-400 block mt-0.5">
                      {div.role}
                    </span>
                  </div>
                </button>
              );
            })}

            {/* Department General Stats */}
            <div className="mt-6 grid grid-cols-3 gap-2 bg-black/30 p-3 rounded-xl border border-white/5 text-center">
              <div>
                <span className="block font-orbitron font-black text-lg text-blue-400">4</span>
                <span className="text-[9px] font-rajdhani text-gray-400 uppercase">Divisões</span>
              </div>
              <div className="border-x border-white/5">
                <span className="block font-orbitron font-black text-lg text-cyan-400">45+</span>
                <span className="text-[9px] font-rajdhani text-gray-400 uppercase">Viaturas</span>
              </div>
              <div>
                <span className="block font-orbitron font-black text-lg text-red-400">100%</span>
                <span className="text-[9px] font-rajdhani text-gray-400 uppercase">Prontidão</span>
              </div>
            </div>

          </div>

          {/* Right: Active Division Rich Multimedia Box */}
          <div className="lg:col-span-7 bg-[#09090f] border border-white/10 rounded-2xl overflow-hidden flex flex-col justify-between group relative holo-card">
            
            {/* Top Media Switcher */}
            <div className="absolute top-3 right-3 z-20 flex items-center gap-1 bg-black/80 backdrop-blur-md p-1 rounded-lg border border-white/10">
              {activeDiv.videoUrl && (
                <button
                  onClick={() => setActiveMedia('video')}
                  className={`px-2.5 py-1 rounded text-xs font-rajdhani font-bold flex items-center gap-1 transition-colors cursor-pointer ${
                    activeMedia === 'video' ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <Video className="w-3.5 h-3.5" />
                  <span>VÍDEO DE AÇÃO</span>
                </button>
              )}

              <button
                onClick={() => setActiveMedia('image')}
                className={`px-2.5 py-1 rounded text-xs font-rajdhani font-bold flex items-center gap-1 transition-colors cursor-pointer ${
                  activeMedia === 'image' || !activeDiv.videoUrl ? 'bg-blue-600 text-white' : 'text-gray-400 hover:text-white'
                }`}
              >
                <Image className="w-3.5 h-3.5" />
                <span>FOTOGRAFIA OFICIAL</span>
              </button>
            </div>

            {/* Media Canvas */}
            <div className="relative h-64 sm:h-80 bg-black overflow-hidden flex items-center justify-center">
              
              {activeMedia === 'video' && activeDiv.videoUrl ? (
                <video
                  src={activeDiv.videoUrl}
                  muted
                  playsInline
                  controls
                  preload="none"
                  className="w-full h-full object-cover holo-image"
                />
              ) : (
                <img
                  src={activeDiv.image}
                  alt={activeDiv.name}
                  loading="lazy"
                  decoding="async"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 holo-image"
                />
              )}

              {/* Bottom Gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#09090f] via-transparent to-transparent pointer-events-none" />

              {/* Tag Over Media */}
              <div className="absolute bottom-3 left-4 z-10">
                <span className="text-[10px] font-mono bg-blue-950/80 text-blue-300 border border-blue-800 px-2.5 py-1 rounded backdrop-blur-md">
                  REGISTO MULTIMÉDIA // {activeDiv.code}
                </span>
              </div>

            </div>

            {/* Content Details */}
            <div className="p-6 space-y-4">
              
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-orbitron font-black text-xl text-white motion-text">
                    {activeDiv.name}
                  </h3>
                </div>
                <p className="font-inter text-sm text-gray-300 mt-2 leading-relaxed">
                  {activeDiv.description}
                </p>
              </div>

              {/* Loadout Section */}
              <div className="pt-2 border-t border-white/5">
                <span className="text-[10px] font-orbitron text-gray-500 uppercase tracking-wider block mb-2.5">
                  Arsenal & Equipamento Padrão
                </span>
                
                <div className="flex flex-wrap gap-2">
                  {activeDiv.equipment.map((item, idx) => (
                    <div key={idx} className="bg-white/5 border border-white/5 px-2.5 py-1 rounded text-xs font-rajdhani text-gray-300 flex items-center gap-1.5">
                      <span className="w-1 h-1 rounded-full bg-blue-400" />
                      {item}
                    </div>
                  ))}
                </div>
              </div>

              {/* Join action */}
              <div className="pt-4 flex items-center justify-between text-xs text-gray-400">
                <span className="flex items-center gap-1">
                  <UserCheck className="w-3.5 h-3.5 text-emerald-400" /> Vagas de recrutamento activas
                </span>

                <a 
                  href="#recrutamento"
                  className="font-rajdhani font-bold text-blue-400 hover:text-blue-300 transition-colors flex items-center gap-1"
                >
                  CANDIDATAR A ESTA DIVISÃO ➔
                </a>
              </div>

            </div>

          </div>

        </div>

        {/* Bottom Interactive Feature: Police Oath */}
        <div className="mt-12 bg-gradient-to-r from-blue-950/30 via-black/40 to-cyan-950/30 border border-white/5 rounded-xl p-6 text-center max-w-4xl mx-auto kinetic-panel motion-float">
          <p className="font-orbitron text-xs text-gray-400 italic">
            "Prometo perante a corporação e aos cidadãos de Darkside RP cumprir e fazer cumprir as leis, agindo com bravura contra a criminalidade e respeitando a integridade da cidade. Força e Honra!"
          </p>
          <span className="block font-rajdhani font-bold text-[10px] text-blue-400 tracking-widest mt-2 uppercase">
            - Juramento Oficial de Admissão DPDK
          </span>
        </div>

      </div>
    </section>
  );
};
