import React, { useState } from 'react';
import { CheckCircle, ExternalLink, ShieldCheck } from 'lucide-react';
import { DPDKLogo } from './DPDKLogo';

export const DiscordConnect: React.FC = () => {
  const [discordUser, setDiscordUser] = useState('');
  const [isConnected, setIsConnected] = useState(false);

  const connect = () => {
    setIsConnected(true);
    window.open('https://discord.gg/bs7EjRJekb', '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="discord" className="relative px-4 sm:px-6 lg:px-8 py-12 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_24%_20%,rgba(147,51,234,0.24),transparent_30%),radial-gradient(circle_at_80%_75%,rgba(59,130,246,0.18),transparent_32%)]" />
      <div className="relative max-w-4xl mx-auto min-h-[620px] rounded-[2rem] overflow-hidden flex items-center justify-center bg-[#17002d] border border-white/10">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_20%_80%,rgba(168,85,247,0.75),transparent_36%),radial-gradient(ellipse_at_82%_18%,rgba(196,181,253,0.55),transparent_30%),linear-gradient(150deg,#250044,#0d001d_58%,#260050)]" />
        <div className="absolute -left-16 bottom-0 w-[420px] h-[760px] rounded-full border-[34px] border-violet-300/30 rotate-[28deg]" />
        <div className="absolute right-[-90px] top-[-120px] w-[360px] h-[620px] rounded-full border-[30px] border-fuchsia-300/25 rotate-[32deg]" />

        <div className="relative z-10 w-full max-w-xl mx-4 rounded-[2rem] bg-white/[0.06] border border-white/40 backdrop-blur-md px-7 sm:px-12 py-10 sm:py-12 shadow-[0_30px_100px_rgba(0,0,0,0.45)]">
          <div className="flex flex-col items-center text-center">
            <div className="w-28 h-28 rounded-3xl bg-black/30 border border-white/20 flex items-center justify-center mb-5 shadow-[0_0_35px_rgba(168,85,247,0.28)]">
              <DPDKLogo className="w-24 h-24" />
            </div>
            <span className="font-orbitron text-xs tracking-[0.35em] uppercase text-violet-200">DPDK</span>
            <h2 className="font-orbitron font-black text-3xl sm:text-4xl text-white mt-3">Conectar Discord</h2>
            <p className="text-sm text-violet-100/80 mt-2 max-w-sm">
              Liga a tua identidade Discord à candidatura e entra directamente no servidor oficial da polícia DPDK.
            </p>
          </div>

          <div className="mt-8 space-y-5">
            <div>
              <label className="block text-sm text-violet-100 mb-2">Discord ID / Utilizador</label>
              <input
                value={discordUser}
                onChange={(event) => setDiscordUser(event.target.value)}
                placeholder="Ex: @utilizador"
                className="w-full h-14 rounded-xl bg-black/20 border-2 border-white/80 px-4 text-white placeholder:text-violet-100/45 focus:outline-none focus:border-violet-300"
              />
            </div>

            <button
              onClick={connect}
              className="w-full h-14 rounded-xl bg-gradient-to-r from-violet-400 to-fuchsia-500 text-white font-orbitron font-bold text-lg shadow-[0_0_35px_rgba(168,85,247,0.38)] flex items-center justify-center gap-2"
            >
              {isConnected ? <CheckCircle className="w-5 h-5" /> : <ShieldCheck className="w-5 h-5" />}
              {isConnected ? 'Discord DPDK Aberto' : 'Conectar com Discord DPDK'}
            </button>

            <a
              href="https://discord.gg/darksiderp"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full h-12 rounded-xl bg-white/10 border border-white/20 text-white font-rajdhani font-bold text-sm flex items-center justify-center gap-2"
            >
              Discord da Cidade Darkside
              <ExternalLink className="w-4 h-4" />
            </a>

            <div className="pt-6 text-center text-violet-100/80 text-sm">
              {discordUser ? `Utilizador preparado: ${discordUser}` : 'Insere o teu Discord antes de enviares a candidatura.'}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};