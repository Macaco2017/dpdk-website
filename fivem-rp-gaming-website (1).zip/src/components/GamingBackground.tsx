import React from 'react';

const PARTICLES = Array.from({ length: 34 }, (_, index) => ({
  id: index,
  left: `${(index * 29) % 100}%`,
  delay: `${(index * 0.37) % 7}s`,
  duration: `${8 + (index % 8)}s`
}));

export const GamingBackground: React.FC = () => {
  return (
    <div className="gaming-bg" aria-hidden="true">
      {PARTICLES.map((particle) => (
        <span
          key={particle.id}
          className="gaming-particle"
          style={{
            '--left': particle.left,
            '--delay': particle.delay,
            '--duration': particle.duration
          } as React.CSSProperties}
        />
      ))}
    </div>
  );
};