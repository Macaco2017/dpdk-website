import React, { useMemo, useState } from 'react';
import { AlertCircle, CheckCircle, ClipboardCheck, Copy, FileText, Send, ShieldCheck, Terminal, User } from 'lucide-react';

interface Question {
  id: string;
  title: string;
  scenario: string;
  options: string[];
  correctIndex: number;
  principle: string;
}

const QUESTIONS: Question[] = [
  {
    id: 'q1',
    title: 'Abordagem com suspeita armada',
    scenario: 'Durante uma abordagem a um veículo, o condutor sai com as mãos visíveis, mas o passageiro permanece imóvel e parece estar a mexer no porta-luvas. Existem civis próximos e ainda não há disparos.',
    options: [
      'Abrir fogo imediatamente para impedir qualquer risco.',
      'Dar ordem clara ao passageiro, pedir reforço, manter cobertura e escalar a força apenas se existir ameaça directa.',
      'Entrar no veículo à força sem avisar para procurar armas.',
      'Ignorar o passageiro e focar apenas o condutor.'
    ],
    correctIndex: 1,
    principle: 'Escalada proporcional da força e preservação de civis.'
  },
  {
    id: 'q2',
    title: 'Perseguição e segurança pública',
    scenario: 'Um suspeito em fuga entra numa zona com muitos civis, conduz em sentido contrário e a tua unidade é a primeira viatura. O suspeito ainda não disparou contra ninguém.',
    options: [
      'Fazer PIT imediato em qualquer velocidade para terminar a perseguição rapidamente.',
      'Manter acompanhamento, comunicar QTH, velocidade e direcção, pedir unidade secundária e evitar manobras perigosas junto a civis.',
      'Atirar aos pneus sem autorização porque o suspeito está a fugir.',
      'Abandonar a perseguição sem avisar a central.'
    ],
    correctIndex: 1,
    principle: 'Prioridade à segurança pública e comunicação constante.'
  },
  {
    id: 'q3',
    title: 'Refém em assalto a banco',
    scenario: 'Num assalto ao banco, os criminosos têm um refém, exigem veículo de fuga e pedem ausência total de polícia à porta. A equipa ainda não tem atirador em posição.',
    options: [
      'Invadir imediatamente porque assalto a banco deve acabar rápido.',
      'Negociar, ganhar tempo, confirmar estado do refém, montar perímetro e só avançar mediante ordem do comando ou ameaça iminente ao refém.',
      'Prometer tudo aos criminosos e depois quebrar o acordo sem justificação RP.',
      'Mandar o refém correr para fora enquanto os criminosos apontam armas.'
    ],
    correctIndex: 1,
    principle: 'Negociação, cadeia de comando e valorização da vida.'
  },
  {
    id: 'q4',
    title: 'Prova, revista e cadeia de custódia',
    scenario: 'Após uma detenção, encontras arma ilegal, dinheiro ilícito e rádio encriptado. O suspeito alega que a revista foi abusiva e que nada foi registado.',
    options: [
      'Guardar os itens e não escrever relatório porque a prisão já aconteceu.',
      'Registar itens, motivo da revista, local, hora, agentes envolvidos e anexar prova/clip quando possível.',
      'Devolver os itens para evitar reclamações.',
      'Inventar crimes adicionais para justificar a detenção.'
    ],
    correctIndex: 1,
    principle: 'Transparência, prova e relatório completo.'
  },
  {
    id: 'q5',
    title: 'Abuso de autoridade em RP',
    scenario: 'Um superior hierárquico manda-te prender um civil apenas porque ele foi inconveniente verbalmente, sem ameaça, crime ou desobediência formal.',
    options: [
      'Cumprir sempre a ordem sem questionar porque veio de um superior.',
      'Recusar de forma respeitosa, pedir fundamentação legal/RP e reportar pela via interna se houver abuso.',
      'Prender o civil e depois libertar em segredo.',
      'Discutir publicamente com o superior no meio da rua.'
    ],
    correctIndex: 1,
    principle: 'Legalidade RP, ética e respeito pela hierarquia sem compactuar com abuso.'
  },
  {
    id: 'q6',
    title: 'Código 0 na frequência',
    scenario: 'Durante uma operação com reféns, o comandante declara Código 0. Um agente começa a comentar assuntos paralelos na frequência enquanto a negociação está activa.',
    options: [
      'Ignorar, porque todos têm direito a falar.',
      'Relembrar de forma curta que está Código 0 e manter a frequência livre para comando e unidades essenciais.',
      'Expulsar o agente da operação sem avisar ninguém.',
      'Responder com brincadeiras para aliviar a tensão.'
    ],
    correctIndex: 1,
    principle: 'Disciplina de comunicação e prioridade operacional.'
  },
  {
    id: 'q7',
    title: 'Meta-gaming e informação externa',
    scenario: 'Um amigo envia-te por Discord a localização de uma facção inimiga, mas a tua personagem não recebeu essa informação dentro do jogo.',
    options: [
      'Usar a informação porque ajuda a polícia.',
      'Não usar a informação, manter separação IC/OOC e apenas agir se houver denúncia ou investigação válida em RP.',
      'Ir ao local sem avisar ninguém e fingir que foi patrulha aleatória.',
      'Partilhar a localização na rádio como se fosse uma fonte oficial.'
    ],
    correctIndex: 1,
    principle: 'Separação IC/OOC e combate ao meta-gaming.'
  },
  {
    id: 'q8',
    title: 'Uso de força letal',
    scenario: 'Um suspeito foge a pé depois de roubar uma loja. Não tem arma visível, não ameaça civis e está a tentar esconder-se num beco.',
    options: [
      'Usar arma letal porque roubo justifica disparo.',
      'Tentar contenção, taser se houver oportunidade segura, comandos verbais e apoio; arma letal apenas perante ameaça letal real.',
      'Atropelar o suspeito com a viatura.',
      'Abandonar a ocorrência porque deixou de ser perseguição automóvel.'
    ],
    correctIndex: 1,
    principle: 'Uso proporcional da força e preservação da vida.'
  },
  {
    id: 'q9',
    title: 'Corrupção e conflito de interesses',
    scenario: 'Um membro de uma organização criminosa oferece dinheiro e informação para que ignores uma apreensão pequena hoje e o ajudes numa operação futura.',
    options: [
      'Aceitar, desde que seja pouco dinheiro e ninguém veja.',
      'Recusar, registar a tentativa de corrupção, informar superior e preservar prova se possível.',
      'Aceitar a informação e não reportar o dinheiro.',
      'Fingir aceitar e fazer tudo sozinho sem informar comando.'
    ],
    correctIndex: 1,
    principle: 'Integridade policial e reporte pela cadeia de comando.'
  },
  {
    id: 'q10',
    title: 'Relatório pós-intervenção',
    scenario: 'Após uma operação grande, vários agentes saem de serviço sem relatório. Houve detidos, apreensões e uso de força. Como deve agir o oficial responsável?',
    options: [
      'Fechar o caso sem relatório porque todos viram o que aconteceu.',
      'Recolher versões essenciais, listar agentes, detidos, provas, uso de força, QTH e anexos multimédia para auditoria interna.',
      'Apagar clips para evitar polémicas.',
      'Colocar toda a culpa no agente com patente mais baixa.'
    ],
    correctIndex: 1,
    principle: 'Responsabilidade, auditoria e documentação operacional.'
  }
];

export const RecruitmentForm: React.FC = () => {
  const [characterName, setCharacterName] = useState('');
  const [passportId, setPassportId] = useState('');
  const [discordTag, setDiscordTag] = useState('');
  const [playerAge, setPlayerAge] = useState('');
  const [availability, setAvailability] = useState('4 a 6 horas');
  const [experience, setExperience] = useState('Intermédia');
  const [motivation, setMotivation] = useState('');
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [submittedData, setSubmittedData] = useState<any | null>(null);
  const [copied, setCopied] = useState(false);
  const [webhookUrl, setWebhookUrl] = useState(() => {
    if (typeof window === 'undefined') return '';
    return window.localStorage.getItem('dpdk_webhook_url') || '';
  });
  const [webhookStatus, setWebhookStatus] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');

  const score = useMemo(() => {
    return QUESTIONS.reduce((total, question) => total + (answers[question.id] === question.correctIndex ? 1 : 0), 0);
  }, [answers]);

  const answeredCount = Object.keys(answers).length;
  const minimumScore = 8;
  const isApproved = score >= minimumScore;

  const deliverWebhook = async (payloadToSend: any) => {
    if (!webhookUrl.trim()) {
      setWebhookStatus('error');
      return;
    }

    try {
      setWebhookStatus('sending');
      const response = await fetch(webhookUrl.trim(), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payloadToSend)
      });

      if (!response.ok) throw new Error(`Discord webhook falhou: ${response.status}`);
      setWebhookStatus('success');
    } catch (error) {
      console.error(error);
      setWebhookStatus('error');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!characterName || !passportId || !discordTag || !motivation || answeredCount < QUESTIONS.length) {
      alert('Preenche todos os campos obrigatórios e responde ao questionário completo.');
      return;
    }

    const answerDetails = QUESTIONS.map((question, index) => {
      const selected = answers[question.id];
      const selectedAnswer = question.options[selected] || 'Sem resposta';
      const correctAnswer = question.options[question.correctIndex];
      return {
        name: `Cenário ${index + 1}: ${question.title}`,
        value: [
          `**Resultado:** ${selected === question.correctIndex ? 'Correcta' : 'Incorrecta'}`,
          `**Resposta do candidato:** ${selectedAnswer}`,
          `**Resposta esperada:** ${correctAnswer}`,
          `**Princípio avaliado:** ${question.principle}`
        ].join('\n'),
        inline: false
      };
    });

    const questionEmbeds = Array.from({ length: Math.ceil(answerDetails.length / 2) }, (_, chunkIndex) => ({
      title: `Respostas ao Questionário DPDK - Parte ${chunkIndex + 1}`,
      color: isApproved ? 3066993 : 15158332,
      fields: answerDetails.slice(chunkIndex * 2, chunkIndex * 2 + 2)
    }));

    const payload = {
      username: 'DPDK Recrutamento',
      content: `**NOVA CANDIDATURA DPDK // QUESTIONÁRIO RP POLICIAL**\nCandidato: **${characterName}**\nDiscord: **${discordTag}**\n<@&112233445566778899> Comando, foi recebida uma candidatura completa com teste de cenário.`,
      embeds: [
        {
          title: `Candidatura DPDK: ${characterName}`,
          description: 'Todas as informações preenchidas pelo candidato e resultado do questionário foram incluídos neste envio.',
          color: isApproved ? 3066993 : 15158332,
          fields: [
            { name: 'Nome do Personagem', value: characterName, inline: true },
            { name: 'Passaporte', value: passportId, inline: true },
            { name: 'Discord', value: discordTag, inline: true },
            { name: 'Idade Real', value: playerAge || 'Não informada', inline: true },
            { name: 'Disponibilidade', value: availability, inline: true },
            { name: 'Experiência RP Policial', value: experience, inline: true },
            { name: 'Resultado do Questionário', value: `${score}/${QUESTIONS.length} (${isApproved ? 'Apto para entrevista' : 'Requer revisão'})`, inline: false },
            { name: 'Motivação', value: motivation, inline: false }
          ],
          footer: { text: 'DPDK • Recrutamento e Avaliação RP' },
          timestamp: new Date().toISOString()
        },
        ...questionEmbeds
      ]
    };

    setSubmittedData(payload);

    if (webhookUrl.trim()) {
      await deliverWebhook(payload);
    }
  };

  const copyPayload = () => {
    if (!submittedData) return;
    navigator.clipboard.writeText(JSON.stringify(submittedData, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const resetForm = () => {
    setCharacterName('');
    setPassportId('');
    setDiscordTag('');
    setPlayerAge('');
    setAvailability('4 a 6 horas');
    setExperience('Intermédia');
    setMotivation('');
    setAnswers({});
    setSubmittedData(null);
    setWebhookStatus('idle');
  };

  const handleWebhookUrlChange = (value: string) => {
    setWebhookUrl(value);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('dpdk_webhook_url', value);
    }
    setWebhookStatus('idle');
  };

  return (
    <section id="recrutamento" className="py-20 bg-[#050508] relative border-t border-blue-900/20 overflow-hidden">
      <div className="absolute bottom-0 left-1/3 w-96 h-96 bg-blue-600/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-12 motion-reveal">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-blue-950/60 border border-blue-800/60 mb-3 animate-pulse-glow">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
            <span className="text-[10px] font-orbitron font-bold text-blue-400 uppercase tracking-widest">Recrutamento Operacional</span>
          </div>
          <h2 className="font-orbitron font-black text-3xl sm:text-4xl text-white tracking-tight motion-text glitch-text kinetic-panel rounded-2xl p-2">
            QUESTIONÁRIO <span className="text-blue-500 text-glow-blue">DPDK</span>
          </h2>
          <p className="font-inter text-gray-400 mt-2 text-sm sm:text-base kinetic-panel rounded-xl p-3 border border-white/5 bg-black/20">
            Antes da entrevista, cada candidato responde a cenários complexos sobre abordagem, perseguição, reféns, prova, rádio, ética e força proporcional em RP policial.
          </p>
        </div>

        <div className="bg-[#09090f] border border-white/10 rounded-2xl shadow-2xl overflow-hidden relative sweep-line holo-card">
          <div className="bg-black/50 px-5 py-3 border-b border-white/10 flex items-center justify-between relative z-10">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              <span className="text-xs font-mono text-gray-400 ml-2">dpdk_recrutamento@questionario:~</span>
            </div>
            <div className="hidden sm:flex items-center gap-1 text-[10px] font-mono text-blue-400 bg-blue-950/60 px-2 py-0.5 rounded border border-blue-800">
              <ClipboardCheck className="w-3 h-3" />
              <span>{answeredCount}/{QUESTIONS.length} respostas</span>
            </div>
          </div>

          <div className="p-6 sm:p-8 relative z-10">
            {!submittedData ? (
              <form onSubmit={handleSubmit} className="space-y-8">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-xs font-orbitron text-gray-300 uppercase mb-1.5 flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-blue-400" /> Nome do Personagem *
                    </label>
                    <input required value={characterName} onChange={(e) => setCharacterName(e.target.value)} placeholder="Ex: Duarte Silva" className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-blue-500 focus:outline-none" />
                  </div>

                  <div>
                    <label className="block text-xs font-orbitron text-gray-300 uppercase mb-1.5 flex items-center gap-1.5">
                      <FileText className="w-3.5 h-3.5 text-blue-400" /> Passaporte / ID *
                    </label>
                    <input required type="number" value={passportId} onChange={(e) => setPassportId(e.target.value)} placeholder="Ex: 1420" className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-blue-500 focus:outline-none" />
                  </div>

                  <div>
                    <label className="block text-xs font-orbitron text-gray-300 uppercase mb-1.5 flex items-center gap-1.5">
                      <Terminal className="w-3.5 h-3.5 text-blue-400" /> Discord *
                    </label>
                    <input required value={discordTag} onChange={(e) => setDiscordTag(e.target.value)} placeholder="Ex: @utilizador" className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-blue-500 focus:outline-none" />
                  </div>

                  <div>
                    <label className="block text-xs font-orbitron text-gray-300 uppercase mb-1.5">Idade Real</label>
                    <input type="number" value={playerAge} onChange={(e) => setPlayerAge(e.target.value)} placeholder="Ex: 18" className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-blue-500 focus:outline-none" />
                  </div>

                  <div>
                    <label className="block text-xs font-orbitron text-gray-300 uppercase mb-1.5">Disponibilidade diária</label>
                    <select value={availability} onChange={(e) => setAvailability(e.target.value)} className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-blue-500 focus:outline-none">
                      <option>Menos de 2 horas</option>
                      <option>2 a 4 horas</option>
                      <option>4 a 6 horas</option>
                      <option>Mais de 6 horas</option>
                      <option>Apenas fins-de-semana</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-orbitron text-gray-300 uppercase mb-1.5">Experiência RP policial</label>
                    <select value={experience} onChange={(e) => setExperience(e.target.value)} className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-blue-500 focus:outline-none">
                      <option>Iniciante</option>
                      <option>Intermédia</option>
                      <option>Avançada</option>
                      <option>Ex-comando / instrutor</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-orbitron text-gray-300 uppercase mb-1.5">Motivação e perfil *</label>
                  <textarea required rows={4} value={motivation} onChange={(e) => setMotivation(e.target.value)} placeholder="Explica como lidas com pressão, hierarquia, denúncias, detenções e conflitos em RP." className="w-full bg-black/40 border border-white/10 rounded-xl p-4 text-sm text-white focus:border-blue-500 focus:outline-none" />
                </div>

                <div className="bg-black/30 p-4 rounded-xl border border-white/5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                  <div className="flex items-start gap-2 text-xs text-gray-400">
                    <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <span>Necessitas de pelo menos <strong className="text-white">{minimumScore}/{QUESTIONS.length}</strong> para ficar apto a entrevista. O comando pode rever respostas manualmente.</span>
                  </div>
                  <div className={`text-sm font-orbitron font-black ${isApproved ? 'text-emerald-400' : 'text-amber-400'}`}>
                    Score: {score}/{QUESTIONS.length}
                  </div>
                </div>

                <div className="bg-blue-950/20 border border-blue-800/40 rounded-xl p-4">
                  <label className="block text-xs font-orbitron text-blue-300 uppercase mb-1.5">Webhook do Discord DPDK</label>
                  <input
                    type="url"
                    value={webhookUrl}
                    onChange={(e) => handleWebhookUrlChange(e.target.value)}
                    placeholder="Cola aqui o URL do webhook do canal de candidaturas DPDK"
                    className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-xs text-white font-mono focus:border-blue-500 focus:outline-none"
                  />
                  <p className="text-[10px] text-gray-500 mt-2 leading-relaxed">
                    Por segurança, o URL fica guardado apenas neste navegador. Se estiver preenchido, a candidatura é enviada automaticamente para o canal do Discord através do webhook.
                  </p>
                </div>

                <div className="space-y-4">
                  {QUESTIONS.map((question, questionIndex) => (
                    <div key={question.id} className="bg-black/25 border border-white/5 rounded-2xl p-5 motion-reveal holo-card overflow-hidden" style={{ animationDelay: `${Math.min(questionIndex, 6) * 80}ms` }}>
                      <div className="flex items-start justify-between gap-4 mb-3">
                        <div>
                          <span className="text-[10px] font-orbitron text-blue-400 uppercase tracking-widest">Cenário {questionIndex + 1}</span>
                          <h3 className="font-orbitron font-bold text-white text-base mt-1">{question.title}</h3>
                        </div>
                        <span className={`text-[10px] font-rajdhani font-bold px-2 py-0.5 rounded border ${answers[question.id] !== undefined ? 'text-emerald-400 border-emerald-800 bg-emerald-950/30' : 'text-gray-400 border-white/10 bg-white/5'}`}>
                          {answers[question.id] !== undefined ? 'Respondido' : 'Pendente'}
                        </span>
                      </div>
                      <p className="text-sm text-gray-300 leading-relaxed mb-4">{question.scenario}</p>
                      <div className="grid grid-cols-1 gap-2">
                        {question.options.map((option, optionIndex) => {
                          const selected = answers[question.id] === optionIndex;
                          return (
                            <label key={option} className={`flex items-start gap-3 p-3 rounded-xl border cursor-pointer transition-all ${selected ? 'bg-blue-950/45 border-blue-500 text-white' : 'bg-white/[0.015] border-white/5 text-gray-300 hover:bg-white/[0.04]'}`}>
                              <input
                                type="radio"
                                name={question.id}
                                checked={selected}
                                onChange={() => setAnswers((prev) => ({ ...prev, [question.id]: optionIndex }))}
                                className="mt-1 accent-blue-500"
                              />
                              <span className="text-sm leading-relaxed">{option}</span>
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>

                <button type="submit" className="w-full py-4 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-orbitron font-bold text-sm tracking-wider rounded-xl shadow-lg glow-blue transition-all cursor-pointer flex items-center justify-center gap-2">
                  <Send className="w-4 h-4" />
                  ENVIAR CANDIDATURA PARA O DISCORD DPDK
                </button>
              </form>
            ) : (
              <div className="animate-fade-in space-y-6">
                <div className="text-center py-4">
                  <div className={`w-16 h-16 rounded-full border flex items-center justify-center mx-auto mb-4 animate-bounce ${isApproved ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-amber-500/10 border-amber-500/30 text-amber-400'}`}>
                    <CheckCircle className="w-8 h-8" />
                  </div>
                  <h3 className="font-orbitron font-black text-2xl text-white motion-text">CANDIDATURA FORMATADA</h3>
                  <p className="text-sm mt-1 font-rajdhani text-gray-300">
                    Resultado do questionário: <strong className={isApproved ? 'text-emerald-400' : 'text-amber-400'}>{score}/{QUESTIONS.length}</strong>
                  </p>
                </div>

                <div className="bg-[#313338] text-[#dbdee1] rounded-lg p-4 font-sans text-sm space-y-3 border border-[#1e1f22]">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center font-orbitron font-bold text-white text-xs shrink-0">DPDK</div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-white text-xs">Central de Candidaturas DPDK</span>
                        <span className="bg-[#5865F2] text-white text-[9px] px-1 rounded font-bold uppercase">BOT</span>
                      </div>
                      <span className="text-[10px] text-[#949ba4]">Hoje às {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                  </div>
                  <p className="text-xs text-[#dbdee1] whitespace-pre-line">{submittedData.content}</p>
                  <div className="bg-[#2b2d31] border-l-4 border-[#2563eb] rounded p-3 space-y-2">
                    <span className="font-bold text-white text-xs block">{submittedData.embeds[0].title}</span>
                    <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                      {submittedData.embeds[0].fields.slice(0, 8).map((field: any, index: number) => (
                        <div key={index} className={field.inline ? '' : 'col-span-2'}>
                          <span className="text-[#949ba4] block text-[10px] font-bold">{field.name}</span>
                          <span className="text-white font-mono whitespace-pre-wrap">{field.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className={`rounded-xl border p-3 text-xs font-rajdhani font-bold ${
                  webhookStatus === 'success'
                    ? 'bg-emerald-950/40 border-emerald-700 text-emerald-300'
                    : webhookStatus === 'error'
                      ? 'bg-amber-950/40 border-amber-700 text-amber-300'
                      : 'bg-white/[0.03] border-white/10 text-gray-400'
                }`}>
                  {webhookStatus === 'success' && 'Webhook entregue com sucesso no Discord DPDK.'}
                  {webhookStatus === 'sending' && 'A enviar candidatura para o webhook do Discord DPDK...'}
                  {webhookStatus === 'error' && 'Webhook não configurado ou falhou. Confirma o URL do webhook no formulário e tenta novamente.'}
                  {webhookStatus === 'idle' && 'Candidatura pronta. Podes enviar via webhook ou copiar o JSON.'}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <button onClick={() => deliverWebhook(submittedData)} disabled={webhookStatus === 'sending'} className="sm:col-span-2 py-3 bg-[#5865F2] hover:bg-[#4752C4] disabled:opacity-60 disabled:cursor-not-allowed text-white font-orbitron font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-2">
                    <Send className="w-4 h-4" />
                    {webhookStatus === 'sending' ? 'A ENVIAR...' : 'ENTREGAR VIA WEBHOOK DPDK'}
                  </button>
                  <button onClick={copyPayload} className="py-3 bg-white/10 hover:bg-white/15 text-white font-rajdhani font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-1.5">
                    <Copy className="w-4 h-4" />
                    {copied ? 'COPIADO' : 'COPIAR JSON'}
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <a href="https://discord.gg/bs7EjRJekb" target="_blank" rel="noopener noreferrer" className="py-3 bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-700 font-orbitron font-bold text-xs rounded-lg transition-colors text-center">
                    ABRIR DISCORD DPDK
                  </a>
                  <button onClick={resetForm} className="py-3 bg-white/5 hover:bg-white/10 text-gray-300 font-rajdhani font-bold text-xs rounded-lg transition-colors">
                    PREENCHER NOVA CANDIDATURA
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};