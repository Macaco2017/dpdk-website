import React, { useState, useEffect } from 'react';
import { Menu, X, Terminal, AlertTriangle } from 'lucide-react';
import { DPDKLogo } from './DPDKLogo';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [defcon, setDefcon] = useState<'NORMAL' | 'ALERTA' | 'CRÍTICO'>('NORMAL');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'inicio', label: 'QG Central' },
    { id: 'sobre', label: 'Departamento' },
    { id: 'frota', label: 'Hierarquia' },
    { id: 'intervencoes', label: 'Intervenções & Operações', highlight: true },
    { id: 'cad', label: 'Códigos Rádio' },
    { id: 'recrutamento', label: 'Candidatura', highlight: true },
  ];

  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const cycleDefcon = () => {
    if (defcon === 'NORMAL') setDefcon('ALERTA');
    else if (defcon === 'ALERTA') setDefcon('CRÍTICO');
    else setDefcon('NORMAL');
  };

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-[#050508]/95 backdrop-blur-md border-b border-blue-900/20 py-3 shadow-2xl' : 'bg-transparent py-5'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          
          {/* Logo & Branding */}
          <div 
            onClick={() => handleNavClick('inicio')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="relative">
              <div className="w-12 h-12 rounded-lg bg-black/60 flex items-center justify-center border border-orange-400/40 shadow-lg group-hover:scale-105 transition-transform overflow-hidden">
                <DPDKLogo className="h-full w-full p-0.5" />
              </div>
              <div className="absolute -inset-1 bg-gradient-to-tr from-orange-500 via-blue-600 to-cyan-500 rounded-lg blur-sm opacity-40 group-hover:opacity-75 transition-opacity -z-10" />
            </div>

            <div className="flex flex-col">
              <div className="flex items-center gap-1.5">
                <span className="font-orbitron font-black text-xl tracking-wider text-white leading-none">
                  DP<span className="text-blue-500">DK</span>
                </span>
                <span className="text-[9px] bg-blue-950 text-blue-400 px-1.5 py-0.2 rounded border border-blue-800 font-mono">v3.0</span>
              </div>
              <span className="font-rajdhani font-bold text-[10px] tracking-widest text-gray-400 uppercase">
                Polícia Darkside RP
              </span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`px-3 py-1.5 rounded-md font-rajdhani font-bold text-sm tracking-wide transition-all cursor-pointer relative ${
                    isActive 
                      ? 'text-white' 
                      : item.highlight 
                        ? 'text-blue-400 hover:text-blue-300' 
                        : 'text-gray-400 hover:text-white'
                  }`}
                >
                  {item.highlight && <span className="absolute -top-1 -right-1 flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
                  </span>}
                  
                  {item.label}

                  {/* Active bottom indicator line */}
                  {isActive && (
                    <span className="absolute bottom-0 left-2 right-2 h-0.5 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Status Controls */}
          <div className="hidden sm:flex items-center gap-3">
            
            {/* Interactive DEFCON Status */}
            <button
              onClick={cycleDefcon}
              title="Clica para alternar o nível de ameaça da cidade"
              className={`flex items-center gap-2 px-3 py-1 border rounded-full transition-all cursor-pointer ${
                defcon === 'NORMAL' 
                  ? 'bg-blue-950/40 border-blue-800/50 text-blue-400' 
                  : defcon === 'ALERTA'
                    ? 'bg-amber-950/40 border-amber-800/50 text-amber-400'
                    : 'bg-red-950/40 border-red-800/50 text-red-400'
              }`}
            >
              <AlertTriangle className={`w-3.5 h-3.5 ${
                defcon === 'CRÍTICO' ? 'animate-bounce' : ''
              }`} />
              <div className="flex flex-col text-left">
                <span className="text-[8px] font-orbitron uppercase text-gray-500 leading-none">Status RDM</span>
                <span className="text-xs font-rajdhani font-bold leading-none mt-0.5">
                  {defcon === 'NORMAL' ? 'CÓDIGO VERDE' : defcon === 'ALERTA' ? 'ALERTA AMARELO' : 'LEI MARCIAL'}
                </span>
              </div>
            </button>

            {/* Quick Discord Action */}
            <a
              href="https://discord.gg/bs7EjRJekb"
              target="_blank"
              rel="noopener noreferrer"
              className="relative group overflow-hidden rounded-lg p-[1px] focus:outline-none cursor-pointer"
            >
              <span className="absolute inset-0 bg-gradient-to-r from-blue-600 via-cyan-500 to-blue-600 rounded-lg animate-gradient-x" />
              <div className="px-3.5 py-1.5 bg-[#050508] rounded-[7px] transition-colors group-hover:bg-transparent">
                <span className="font-orbitron font-bold text-xs text-white tracking-wider flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                  DISCORD DPDK
                </span>
              </div>
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex sm:hidden items-center gap-2">
            <a
              href="https://discord.gg/bs7EjRJekb"
              target="_blank"
              rel="noopener noreferrer"
              className="px-2.5 py-1 bg-blue-600 text-white font-orbitron font-bold text-xs rounded"
            >
              DPDK
            </a>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-white/5 text-gray-400 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden absolute top-full left-0 right-0 bg-[#050508]/98 border-b border-white/10 px-4 py-6 flex flex-col gap-3 backdrop-blur-xl animate-fade-in">
          
          <div className="flex items-center justify-between px-3 py-2 bg-white/5 rounded-lg mb-2">
            <span className="text-xs text-gray-400 font-rajdhani">Nível de ameaça:</span>
            <button 
              onClick={cycleDefcon}
              className={`text-xs font-orbitron font-bold px-2 py-0.5 rounded border ${
                defcon === 'NORMAL' ? 'text-blue-400 border-blue-800' : defcon === 'ALERTA' ? 'text-amber-400 border-amber-800' : 'text-red-400 border-red-800'
              }`}
            >
              {defcon} (ALTERAR)
            </button>
          </div>

          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`text-left px-3 py-2.5 rounded-lg font-rajdhani font-bold text-base transition-colors ${
                activeTab === item.id 
                  ? 'bg-blue-600/20 text-blue-400 border-l-2 border-blue-500' 
                  : item.highlight
                    ? 'text-cyan-400 bg-cyan-950/20'
                    : 'text-gray-300 hover:bg-white/5'
              }`}
            >
              {item.label}
            </button>
          ))}

          <div className="pt-2">
            <a
              href="https://discord.gg/bs7EjRJekb"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-lg font-orbitron font-bold text-sm text-white shadow-lg flex items-center justify-center gap-2"
            >
              <Terminal className="w-4 h-4" />
              ENTRAR NO DISCORD DPDK
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
